/**Ejercicio 1:
Crear una función con un parámetro llamado edad que permita calcular si una persona es mayor de
edad o no. Utilizar para la condición el operador ternario.**/

function mayorEdad(edad) { 
    return edad >= 18 ? "Es mayor de edad" : "Es menor de edad"; 
}

console.log(mayorEdad(17));



