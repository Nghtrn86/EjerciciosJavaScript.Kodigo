/* Determinar la nota final de un alumno, la cual depende de lo siguiente: Examen =20% , tareas 40%,
asistencia =10% e investigación =30% , al final deberá mostrar los datos del alumno , nombre , carnet
y nota final. Para este ejercicio deberá de utilizar una fuction y asignar parámetros para llenar los
valores. */
​
function notaFinal(nombre, carnet, examen, tareas, asistencia, investigacion) {
    let nota = (examen * 0.2) + (tareas * 0.4) + (asistencia * 0.1) + (investigacion * 0.3);
    return `Nombre: ${nombre} Carnet: ${carnet} Nota final: ${nota}`;
}
​
console.log(notaFinal("Armando", "243456", 7, 10, 5, 8));
console.log(notaFinal("Jose", "1897654", 9, 6, 9, 7));
console.log(notaFinal("Flores", "5443682", 7, 8, 10, 8));
