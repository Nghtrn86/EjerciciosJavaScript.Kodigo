/* Crear una function que tenga 2 parámetros y asignarle números enteros para calcular cual número es
el mayor. */

​
function mayor(num1, num2) {
    return num1 > num2 ? num1 : num2;
}
​
console.log(mayor(5, 10));
console.log(mayor(30, 5));