/** Crear una function que tenga 2 parámetros y asignarle números enteros para calcular cual número es
el mayor.**/

const nombre = "Juan Gonzales";
const salario = 1000;
const categoria = "A";
let aumento;
​
if (categoria === "A") {
aumento = salario * 0.15;
} else if (categoria === "B") {
aumento = salario * 0.3;
} else if (categoria === "C") {
aumento = salario * 0.1;
} else if (categoria === "D") {
aumento = salario * 0.2;
}
​
console.log(`El empleado: ${nombre}.\nsalario de: $${salario} dolares. \ncategoría: "${categoria}"\nsu aumento es de: $${aumento} el nuevo salario es de: $${salario + aumento} dolares.`);