/**Ejercicio 2:
Crear  Fuctions que calcule 2 números enteros y muestre en consola el resultado de la suma, resta, multiplicación y división.
 Puede utilizar parámetros o variables locales para asignar valores a los numeros**/

 function suma(num1, num2) {
    return num1 + num2;
}   
​
function resta(num1, num2) {
    return num1 - num2;
}
​
function multiplicacion(num1, num2) {
    return num1 * num2;
}
​
function division(num1, num2) {
    return num1 / num2;
}
​
console.log(suma(2, 2));
console.log(resta(2, 2));
console.log(multiplicacion(2, 2));
console.log(division(2, 2));